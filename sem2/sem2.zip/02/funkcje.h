#pragma once

void zad01();

void zad02();

void zad03();

void zad04();

void zad05();
