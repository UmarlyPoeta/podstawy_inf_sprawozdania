#pragma once

bool koniunkcja(bool p1, bool p2);

bool alternatywa(bool p1, bool p2);

bool negacja(bool p);

bool rownowaznosc(bool p1, bool p2);

bool implikacja(bool p1, bool p2);
